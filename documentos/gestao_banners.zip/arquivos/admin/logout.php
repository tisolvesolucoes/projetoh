<?
session_start();
session_unset();
session_destroy();
?>
<html><HEAD><TITLE>.:: ADMINISTRA��O ::.</TITLE></HEAD>
<script>document.location = 'index.php'</script>
</head><body>
Saindo...
</body></html>

