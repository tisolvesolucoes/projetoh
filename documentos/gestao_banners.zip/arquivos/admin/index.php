<title>.:: ADMINISTRA&Ccedil;&Atilde;O ::.</title><TABLE cellSpacing=0 cellPadding=0 width=500 align=center border=0>
  <TBODY> 
  <TR> 
    <TD width=330 

          height=150> 
      <FORM action='inc/autenticacao.rotinas.php' method=post>
        <BR>
        <TABLE cellSpacing=0 cellPadding=0 width=225 align=right border=0>
          <TBODY> 
          <TR> 
            <TD width=57 height=25> 
              <DIV align=right><SPAN class=style10>Login:</SPAN></DIV>
            </TD>
            <TD width=173 height=25> 
              <INPUT size=20 name='usuario' value='teste@teste.com'>
            </TD>
          </TR>
          <TR> 
            <TD height=25> 
              <DIV align=right><SPAN class=style10>Senha:</SPAN></DIV>
            </TD>
            <TD height=25> 
              <INPUT type='password' size=20 name='senha' value='123456'>
            </TD>
          </TR>
          <TR> 
            <TD colSpan=2 height=25> 
              <DIV align=center> 
                <input type='hidden' name="enviado" value="posted">
                <INPUT type=submit value=":: Entrar ::" name=Submit>
              </DIV>
            </TD>
          </TR>
          </TBODY>
        </TABLE>
        <DIV class=style7 align=center><BR>
          <BR>
        </DIV>
      </FORM>
      <DIV align=right><SPAN class=style7></SPAN></DIV>
    </TD>
  </TR>
  </TBODY>
</TABLE>

      
